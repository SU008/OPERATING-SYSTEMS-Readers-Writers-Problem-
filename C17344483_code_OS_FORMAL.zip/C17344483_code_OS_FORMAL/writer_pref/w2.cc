/*
Name: Sajjad Ullah, C17344483
This is a solution to the readers-writers problem 
Using 2 readers (r1, r2) & 2 writers (w1,w2) 


writers-preference:no writer, once added to the queue, 
shall be kept waiting longer than absolutely necessary.


Instruction:
Note w1 must run first 
as the initilsation of the semaphores 
and 2 counters is done in w1

Created using source: https://en.wikipedia.org/wiki/Readers%E2%80%93writers_problem
*/
#include<sys/types.h>     
#include<sys/ipc.h>       
#include<sys/sem.h>       
#include<sys/shm.h>       

#include<iostream>
#include<cstdio>

#include<fstream>
#include<string>

#define SEMKEY1 151 
#define SEMKEY2 152 
#define SEMKEY3 153 
#define SEMKEY4 154 

#define SHM_KEY1 9876
#define SHM_KEY2 9877
using namespace std;


int main()
{ 

        printf("\n--------main is Starting for writer 2 ------------\n");
  
        int shmid1,shmid2,   semid1,semid2, semid3,semid4;
        int *ptr_read_count, *ptr_write_count;


	/*shmid1 will be the rmutex */
        semid1 = semget(SEMKEY1, 1 , 0777|IPC_CREAT); 
   	//semctl(semid1,0,SETVAL,1);
   	
	/*shmid2 will be the wmutex */
        semid2 = semget(SEMKEY2, 1 , 0777|IPC_CREAT);
   	//semctl(semid2,0,SETVAL,1);  
   	
   	/*shmid3 will be the readTry */
        semid3 = semget(SEMKEY3, 1 , 0777|IPC_CREAT);
   	//semctl(semid3,0,SETVAL,1);   
   	
   	/*shmid4 will be the resource */
        semid4 = semget(SEMKEY4, 1 , 0777|IPC_CREAT);
   	//semctl(semid4,0,SETVAL,1);  
   
   
   
   
   
   
   
   
   	/* shmid1 is shared memory for the readcounter */
	shmid1 = shmget(SHM_KEY1, 256 , 0777|IPC_CREAT);
       
	/*read count pointer points to first location in shared memory*/
        ptr_read_count = (int*)shmat(shmid1, 0, 0);
        //*ptr_read_count = 0; 
        
        
        
   	/* shmid2 is shared memory for the writecount */
	shmid2 = shmget(SHM_KEY2, 256 , 0777|IPC_CREAT);
       
	/*read count pointer points to first location in shared memory*/
        ptr_write_count = (int*)shmat(shmid2, 0, 0);
        //*ptr_write_count = 0; 
 


	/*define a number of variables of type sembuf*/
        struct sembuf Wrmutex, Srmutex, Wwmutex, Swmutex, WreadTry,SreadTry,Wresource, Sresource;

	/* initilise the structure memebers*/
	Wrmutex.sem_num = 0;
	Wrmutex.sem_op = -1;
	Wrmutex.sem_flg = SEM_UNDO;
	
	Srmutex.sem_num = 0;
	Srmutex.sem_op = 1;
	Srmutex.sem_flg = SEM_UNDO;
	
	        
	Wwmutex.sem_num = 0;
	Wwmutex.sem_op = -1;
	Wwmutex.sem_flg = SEM_UNDO;
	
	Swmutex.sem_num = 0;
	Swmutex.sem_op = 1;
	Swmutex.sem_flg = SEM_UNDO;
	
	
	WreadTry.sem_num = 0;
	WreadTry.sem_op = -1;
	WreadTry.sem_flg = SEM_UNDO;
	
	SreadTry.sem_num = 0;
	SreadTry.sem_op = 1;
	SreadTry.sem_flg = SEM_UNDO;
	
	
	Wresource.sem_num = 0;
	Wresource.sem_op = -1;
	Wresource.sem_flg = SEM_UNDO;
	
	Sresource.sem_num = 0;
	Sresource.sem_op = 1;
	Sresource.sem_flg = SEM_UNDO;
	
	


 while(1){
		
			/*reserve entry section for writers 
			avoids race conditon with readers */
			semop(semid2, &Wwmutex,1); 
			
						
			
			*ptr_write_count = *ptr_write_count + 1;//increment the readcount
			printf("\nEntry number of write count = %d \n", *ptr_write_count);
                       

			if( *ptr_write_count == 1 ){ //checks if you are first writer
			
			/*if you're first, then you must lock the readers out. 
			Prevent them from trying to enter CS */
			 semop(semid3, &WreadTry,1); 
			}
			
				
			/*release entry section */		
			semop(semid2, &Swmutex,1); 
			
			/*reserve the resource for yourself 
			prevents other writers from simultaneously editing the shared resource*/
			semop(semid4, &Wresource,1); 


			//Entry Critical Section (CS) 

			//-------------writing is done 
		
			     	char input;
				cout<<"\n Do u want to write to file [y/n] => ";
				cin>> input;
				cout<<endl;
				string line;
				ofstream myfile ("example.txt", fstream::app); //open in append mode using "app"
				if(myfile.is_open() ){
					cout<<"\nEnter input to save to file => ";
					cin>>line;
					
					myfile <<line <<"\n ";
					myfile.close();

				}
				
		
			//----------------------

			//Exit Critical Section (CS)

			/*release file*/			
			semop(semid4, &Sresource,1); 


			/*reserve exit section*/
			semop(semid2, &Wwmutex,1); 
			
			
			/*decrement the write count when exiting */
			*ptr_write_count = *ptr_write_count - 1;

			printf("\nExit number of write count = %d \n", *ptr_write_count);
			
			
			if( *ptr_write_count == 0 ){//checks if you are last writer leaving
			
			/*if last, you must unlock the readers.
			 Allows them to try enter CS for reading */
			 semop(semid3, &SreadTry,1); 
			}
			
			
			
			/*release exit section for other readers*/
			semop(semid2, &Swmutex,1); 

	
 }
	
        

        return 0;
}
	


   


 
