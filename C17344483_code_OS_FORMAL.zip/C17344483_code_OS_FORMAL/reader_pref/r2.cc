/*
Name: Sajjad Ullah, C17344483
This is a solution to the readers-writers problem 
Using 2 readers (r1, r2) & 2 writers (w1,w2) 


readers-preference:no reader shall be kept waiting 
if the resource is currently opened for reading.



Note r1 must run first 
as the initilsation of the semaphores 
and reader_counter is done in r1

Created using source: https://en.wikipedia.org/wiki/Readers%E2%80%93writers_problem

*/
#include<sys/types.h>     //for wait() 
#include<sys/ipc.h>       //for all IPC function calls
#include<sys/sem.h>       //for semget(), shmat, shmctl()
#include<sys/shm.h>       //for shmget(), shmat, shmctl

#include<iostream>
#include<cstdio>

#include<fstream>
#include<string>

#define SEMKEY1 151 
#define SEMKEY2 152 
#define SHM_KEY 9876
using namespace std;


int main()
{ 

        printf("\n--------main is Starting for reader ------------\n");
  
        int shmid,semid1,semid2;
        int *ptr_read_count;


	/*semid1 will be the mutex */
        semid1 = semget(SEMKEY1, 1 , 0777|IPC_CREAT); 
   	//semctl(semid1,0,SETVAL,1);
   	

	/*semid2 will be the resource */
        semid2 = semget(SEMKEY2, 1 , 0777|IPC_CREAT);
   	//semctl(semid2,0,SETVAL,1); 
   
   	/* shared memeory */
	shmid = shmget(SHM_KEY, 256 , 0777|IPC_CREAT);
        



        ptr_read_count = (int*)shmat(shmid, 0, 0);
       // *ptr_read_count = 0;
 



        struct sembuf Wmutex, Smutex,Wresource, Sresource;

	Wmutex.sem_num = 0;
	Wmutex.sem_op = -1;
	Wmutex.sem_flg = SEM_UNDO;
	
	Smutex.sem_num = 0;
	Smutex.sem_op = 1;
	Smutex.sem_flg = SEM_UNDO;
	
	        
	Wresource.sem_num = 0;
	Wresource.sem_op = -1;
	Wresource.sem_flg = SEM_UNDO;
	
	Sresource.sem_num = 0;
	Sresource.sem_op = 1;
	Sresource.sem_flg = SEM_UNDO;
	
	



 
	while(1){

	
			/*wait signal on mutex to ensure
			 no other reader can enter 
			 critical section 1  */
			semop(semid1, &Wmutex,1); 
			
			//+++++++critical section 1
			
			*ptr_read_count = *ptr_read_count + 1;//increment the readcount
			printf("\nenter number of read count = %d \n", *ptr_read_count);
                       

                       /* Check if this is the first reader 
                       trying to enter critical section 1  */
			if( *ptr_read_count == 1 ){
			
			/*the first reader will lock 
			the resource from writers by wait on resource */
			 semop(semid2, &Wresource,1); 
			}
			
			//+++++++exit critical section 1 
			
			
			/*Critical section 1 exited,
			Release mutex by signal on mutex */
			semop(semid1, &Smutex,1);  

			//-------------reading
				     	char input;
					cout<<"\n Do u want to read to file [y/n] => ";
					cin>> input;
					cout<<endl;
					if (input == 'y'){
						string line;
						ifstream myfile ("example.txt");
						if(myfile.is_open()){
		                                 cout<<"\nContents of file are below:"<<endl;
							  while(getline (myfile,line)  ) {
							  
							  cout<<line <<endl;
							  }
						  myfile.close();
						}
						else cout<<"\nUnable to open file"<<endl;
					}
			//----------------------


			/*Ensure no other reader can execute
			 critical section 2 while we are in it */
			semop(semid1, &Wmutex,1); 

			//++++++++critical section 2
			
			*ptr_read_count = *ptr_read_count - 1;//decrement the read count 

			printf("\n exit number of read count = %d \n", *ptr_read_count);
			
			/*Checks if we are the last reader */
			if( *ptr_read_count == 0 ){
			
			/*if we are last reader unlock the resource */
			 semop(semid2, &Sresource,1); 
			}
			
			//++++++++exit critical section 2
			
			/*release the mutex */
			semop(semid1, &Smutex,1); 

	}
	

	
        

        return 0;
}
	


   


 
